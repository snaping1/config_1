def exit_shell(shell_gui):
    shell_gui.display_output("Выход из оболочки...")
    exit()